<!DOCTYPE html>
<html>
<body>

<?php
$myfile = fopen("abtus.txt", "r") or die("Unable to open file!");
echo fread($myfile,filesize("abtus.txt"));
fclose($myfile);
?>

</body>
</html>