<?php
$conn = mysqli_connect("localhost","root","","notes" ) or die ("error" . mysqli_error($conn));
?>
