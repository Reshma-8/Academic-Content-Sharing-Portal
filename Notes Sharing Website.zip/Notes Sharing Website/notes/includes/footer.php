 <footer class="foo">
            <div class="row">
                <div class="col-lg-12">
                    <p style="text-align:center; font-family: 'Monotype Corsiva'; font-size:17px;"><i class="material-icons" style="color: brown;"></i><b >ACADEMIC CONTENT SHARING PORTAL</b></p>
                </div>
            </div>
   </footer>